# Student Planner

A responsive student planner web application built with HTML, CSS, and JavaScript.

## Features
- Add tasks with subject, due date, and priority
- Mark tasks as completed or delete them
- Search and filter tasks
- View total, completed, and pending tasks
- Track overall progress
- Save tasks in browser Local Storage
- Responsive layout for desktop and mobile

## Run locally
Open `index.html` in a web browser.

## GitHub Pages
Upload `index.html` to the root of a GitHub repository, then enable GitHub Pages in **Settings → Pages** using the `main` branch and `/ (root)` folder.

## Note
Tasks are saved in the current browser on the current device. They do not sync automatically between devices.
